# Installed Skills Manifest

Skills available for loading in this conversation. To activate a skill, Claude should use the `view` tool on its SKILL.md file.

<available_skills>
<skill>
<n>
categorizing-bsky-accounts
</n>
<description>
Analyze and categorize Bluesky accounts by topic using keyword extraction.
</description>
<location>
/home/claude/skills/categorizing-bsky-accounts/SKILL.md
</location>
</skill>

<skill>
<n>
charting-vega-lite
</n>
<description>
Create interactive data visualizations using Vega-Lite declarative JSON grammar.
</description>
<location>
/home/claude/skills/charting-vega-lite/SKILL.md
</location>
</skill>

<skill>
<n>
cloning-project
</n>
<description>
Exports project instructions and knowledge files from the current Claude project.
</description>
<location>
/home/claude/skills/cloning-project/SKILL.md
</location>
</skill>

<skill>
<n>
convening-experts
</n>
<description>
Convenes expert panels for problem-solving.
</description>
<location>
/home/claude/skills/convening-experts/SKILL.md
</location>
</skill>

<skill>
<n>
crafting-instructions
</n>
<description>
Generate optimized instructions for Claude (Project instructions, Skills, or standalone prompts).
</description>
<location>
/home/claude/skills/crafting-instructions/SKILL.md
</location>
</skill>

<skill>
<n>
creating-bookmarklets
</n>
<description>
Creates browser-executable JavaScript bookmarklets with strict formatting requirements.
</description>
<location>
/home/claude/skills/creating-bookmarklets/SKILL.md
</location>
</skill>

<skill>
<n>
creating-mcp-servers
</n>
<description>
Creates production-ready MCP servers using FastMCP v2.
</description>
<location>
/home/claude/skills/creating-mcp-servers/SKILL.md
</location>
</skill>

<skill>
<n>
developing-preact
</n>
<description>
Preact development for dynamic web applications requiring reactive state management, complex interactions, or real-time updates.
</description>
<location>
/home/claude/skills/developing-preact/SKILL.md
</location>
</skill>

<skill>
<n>
extracting-keywords
</n>
<description>
Extract keywords from documents using YAKE algorithm with support for 34 languages (Arabic to Chinese).
</description>
<location>
/home/claude/skills/extracting-keywords/SKILL.md
</location>
</skill>

<skill>
<n>
iterating
</n>
<description>
Multi-conversation methodology for iterative stateful work with context accumulation.
</description>
<location>
/home/claude/skills/iterating/SKILL.md
</location>
</skill>

<skill>
<n>
mapping-codebases
</n>
<description>
Generate navigable code maps for unfamiliar codebases.
</description>
<location>
/home/claude/skills/mapping-codebases/SKILL.md
</location>
</skill>

<skill>
<n>
sampling-bluesky-zeitgeist
</n>
<description>
Sample and analyze Bluesky firehose to identify trending topics and content clusters.
</description>
<location>
/home/claude/skills/sampling-bluesky-zeitgeist/SKILL.md
</location>
</skill>

<skill>
<n>
updating-knowledge
</n>
<description>
Systematic research methodology for building comprehensive, current knowledge on any topic.
</description>
<location>
/home/claude/skills/updating-knowledge/SKILL.md
</location>
</skill>

</available_skills>
