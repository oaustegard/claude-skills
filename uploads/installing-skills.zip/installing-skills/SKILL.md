# Installing Skills

**Purpose:** Dynamically load skills from github.com/oaustegard/claude-skills into the current conversation's working environment while preserving Progressive Disclosure.

**Scope:** Single-conversation only—installed skills don't persist to new chats.

---

## Triggers

- User mentions "install skill", "load skill", or "add skill"
- User requests "available skills" or "show installable skills"
- Beginning of conversation when user needs access to repo skills

---

## Progressive Disclosure Preservation

**CRITICAL:** Do NOT view all SKILL.md files upfront. This violates Progressive Disclosure.

Instead:
1. Extract frontmatter metadata from each SKILL.md
2. Build a discovery manifest (like `<available_skills>`)
3. View manifest only
4. Load individual skills via `view` when triggered

---

## Installation Process

### Step 1: Repository Setup & Discovery

```bash
#!/bin/bash
set -e

REPO_DIR="/home/claude/claude-skills"
SKILLS_DIR="/home/claude/skills"
MANIFEST="/home/claude/skills/INSTALLED_SKILLS_MANIFEST.md"

# Clone or update repository
if [ ! -d "$REPO_DIR" ]; then
    git clone https://github.com/oaustegard/claude-skills.git "$REPO_DIR"
else
    cd "$REPO_DIR" && git pull origin main
fi

# Create skills directory
mkdir -p "$SKILLS_DIR"

# Start manifest
cat > "$MANIFEST" << 'EOF'
# Installed Skills Manifest

Skills available for loading in this conversation. To activate a skill, Claude should use the `view` tool on its SKILL.md file.

<available_skills>
EOF

# Extract frontmatter from each skill
cd "$REPO_DIR"
for skill_dir in */; do
    skill_name=$(basename "$skill_dir")
    skill_file="${skill_dir}SKILL.md"
    
    # Skip non-skill directories
    [[ "$skill_name" =~ ^(templates|\.github|uploads)$ ]] && continue
    [ ! -f "$skill_file" ] && continue
    
    # Copy skill to working directory
    mkdir -p "${SKILLS_DIR}/${skill_name}"
    cp -r "${skill_dir}"* "${SKILLS_DIR}/${skill_name}/"
    rm -f "${SKILLS_DIR}/${skill_name}/VERSION"
    
    # Extract frontmatter (first 20 lines, look for # and description patterns)
    description=""
    name_line=""
    
    # Try to find name (first # heading)
    name_line=$(head -20 "$skill_file" | grep -m1 "^# " | sed 's/^# //' || echo "$skill_name")
    
    # Try to find description (line after **Purpose:** or **Description:**)
    description=$(awk '
        /\*\*Purpose:\*\*|^\*\*Description:\*\*/ { 
            getline; 
            gsub(/^[ \t]+/, ""); 
            gsub(/\*\*/, ""); 
            print; 
            exit 
        }
    ' "$skill_file")
    
    # Fallback: get first paragraph
    if [ -z "$description" ]; then
        description=$(awk '
            /^[A-Z]/ && !/^#/ && !seen { 
                print; 
                seen=1; 
                exit 
            }
        ' "$skill_file")
    fi
    
    # Add to manifest
    cat >> "$MANIFEST" << SKILL_EOF
<skill>
<name>
${skill_name}
</name>
<description>
${description}
</description>
<location>
/home/claude/skills/${skill_name}/SKILL.md
</location>
</skill>

SKILL_EOF
done

# Close manifest
echo "</available_skills>" >> "$MANIFEST"

echo "✓ Skills installed and manifest created"
echo "  Manifest: $MANIFEST"
```

### Step 2: View Manifest Only

After installation completes:
```bash
view /home/claude/skills/INSTALLED_SKILLS_MANIFEST.md
```

Claude should acknowledge the available skills without loading any yet.

### Step 3: Load Skills on Demand

When a trigger pattern matches or user requests a specific skill:
```bash
view /home/claude/skills/{skill-name}/SKILL.md
```

**Example:**
```
User: "Map this codebase"
Claude: [recognizes "map codebase" trigger from manifest]
Claude: [calls view /home/claude/skills/mapping-codebases/SKILL.md]
Claude: [applies skill instructions]
```

---

## User Interaction Patterns

### Install Skills (Initial Setup)
```
User: "Install my skills from GitHub"
Claude: [runs Step 1 script, generates manifest]
Claude: [views manifest]
Claude: "Installed 15 skills from your repository. Skills will load automatically when needed."
```

### List Available
```
User: "What skills did you install?"
Claude: [references previously viewed manifest]
Claude: "Available: categorizing-bsky-accounts, charting-vega-lite, mapping-codebases..."
```

### Explicit Load
```
User: "Load the updating-knowledge skill"
Claude: [views /home/claude/skills/updating-knowledge/SKILL.md]
Claude: "Loaded updating-knowledge skill. Ready for research tasks."
```

### Automatic Load
```
User: "Map this codebase"
Claude: [manifest indicated mapping-codebases triggers on "map"]
Claude: [views /home/claude/skills/mapping-codebases/SKILL.md]
Claude: [proceeds with mapping]
```

---

## Implementation Notes

### Progressive Disclosure
- Manifest contains metadata only (name, description, location)
- Individual SKILL.md files loaded just-in-time
- Matches behavior of native `<available_skills>` system
- Prevents context overflow from loading all skills upfront

### Frontmatter Extraction Strategy
1. First `# Heading` → skill name
2. Line after `**Purpose:**` → description
3. Fallback to first paragraph → description
4. If all fail → use directory name + generic description

### Skill Discovery
Installed skills are functionally equivalent to native skills:
- Same trigger pattern matching
- Same progressive loading
- Same application of instructions
- Location is the only difference (`/home/claude/skills/` vs `/mnt/skills/`)

### Manifest Format
Mirrors native `<available_skills>` XML structure for consistency:
```xml
<available_skills>
<skill>
<name>skill-name</name>
<description>Brief description</description>
<location>/home/claude/skills/skill-name/SKILL.md</location>
</skill>
...
</available_skills>
```

---

## Complete Installation Script

```bash
#!/bin/bash
set -e

REPO_DIR="/home/claude/claude-skills"
SKILLS_DIR="/home/claude/skills"
MANIFEST="${SKILLS_DIR}/INSTALLED_SKILLS_MANIFEST.md"

echo "==> Installing skills from github.com/oaustegard/claude-skills"

# Clone or update
if [ ! -d "$REPO_DIR" ]; then
    echo "==> Cloning repository..."
    git clone https://github.com/oaustegard/claude-skills.git "$REPO_DIR"
else
    echo "==> Updating repository..."
    cd "$REPO_DIR" && git pull origin main
fi

# Setup
mkdir -p "$SKILLS_DIR"
cd "$REPO_DIR"

# Initialize manifest
cat > "$MANIFEST" << 'EOF'
# Installed Skills Manifest

Skills available for loading in this conversation. To activate a skill, Claude should use the `view` tool on its SKILL.md file.

<available_skills>
EOF

# Process each skill
count=0
for skill_dir in */; do
    skill_name=$(basename "$skill_dir")
    skill_file="${skill_dir}SKILL.md"
    
    # Skip non-skills
    [[ "$skill_name" =~ ^(templates|\.github|uploads)$ ]] && continue
    [ ! -f "$skill_file" ] && continue
    
    echo "==> Processing: $skill_name"
    
    # Install skill
    mkdir -p "${SKILLS_DIR}/${skill_name}"
    cp -r "${skill_dir}"* "${SKILLS_DIR}/${skill_name}/"
    rm -f "${SKILLS_DIR}/${skill_name}/VERSION"
    
    # Extract metadata
    name_line=$(head -20 "$skill_file" | grep -m1 "^# " | sed 's/^# //' || echo "$skill_name")
    description=$(awk '
        /\*\*Purpose:\*\*|^\*\*Description:\*\*/ { 
            getline; 
            gsub(/^[ \t]+/, ""); 
            gsub(/\*\*/, ""); 
            print; 
            exit 
        }
    ' "$skill_file")
    
    [ -z "$description" ] && description=$(awk '/^[A-Z]/ && !/^#/ && !seen { print; seen=1; exit }' "$skill_file")
    [ -z "$description" ] && description="Skill for ${skill_name}"
    
    # Add to manifest
    cat >> "$MANIFEST" << SKILL_EOF
<skill>
<name>
${skill_name}
</name>
<description>
${description}
</description>
<location>
/home/claude/skills/${skill_name}/SKILL.md
</location>
</skill>

SKILL_EOF
    
    ((count++))
done

# Finalize manifest
echo "</available_skills>" >> "$MANIFEST"

echo ""
echo "✓ Installed $count skills"
echo "  Manifest: $MANIFEST"
echo ""
echo "Next: Claude should view $MANIFEST"
```

---

## Error Handling

```bash
# Verify git is available
if ! command -v git &> /dev/null; then
    echo "Error: git not found"
    exit 1
fi

# Verify repo cloned successfully
if [ ! -d "$REPO_DIR/.git" ]; then
    echo "Error: Failed to clone repository"
    exit 1
fi

# Verify manifest created
if [ ! -f "$MANIFEST" ]; then
    echo "Error: Failed to create manifest"
    exit 1
fi

# Count skills installed
skill_count=$(grep -c "<skill>" "$MANIFEST" || echo "0")
if [ "$skill_count" -eq 0 ]; then
    echo "Warning: No skills found in repository"
fi
```

---

## Removal

Uninstall all skills:
```bash
rm -rf /home/claude/skills
```

Uninstall specific skill:
```bash
rm -rf /home/claude/skills/${SKILL_NAME}
# Update manifest or regenerate
```

---

## Repository Structure Reference

```
claude-skills/
├── skill-name/
│   ├── SKILL.md          # Main skill instructions
│   ├── VERSION           # Workflow metadata (excluded)
│   └── resources/        # Optional support files
├── templates/            # Not a skill
├── .github/              # Not a skill
└── uploads/              # Not a skill
```

Skills identified by: `SKILL.md` at directory root + not in exclusion list.
