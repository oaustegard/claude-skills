# Installing Skills

**Dynamically load skills from your GitHub repo into the current conversation while preserving Progressive Disclosure.**

## What It Does

This skill allows Claude to:
- Clone/update the `oaustegard/claude-skills` repository
- Install all skills into `/home/claude/skills/`
- Generate a discovery manifest with metadata from each skill
- Load specific skills on-demand when triggered
- Preserve Progressive Disclosure by avoiding upfront loading of all skills

## Why This Exists

The mounted skill directories (`/mnt/skills/`) are read-only and fixed per conversation. This skill bypasses that limitation by:
1. Cloning your repo to writable space
2. Copying skills to working directory
3. Extracting metadata (name, description, location) from each skill
4. Creating a manifest similar to `<available_skills>`
5. Loading individual skills just-in-time when needed

## Progressive Disclosure

**Critical Design:** This skill does NOT load all SKILL.md files upfront.

Instead it:
1. Extracts frontmatter metadata from each skill (name, description)
2. Builds `INSTALLED_SKILLS_MANIFEST.md` with metadata only
3. Claude views the manifest to discover available skills
4. Claude loads individual skills via `view` when triggered by patterns or user requests

This mirrors how native `<available_skills>` works and prevents context overflow.

## Usage

### Install Skills (One-Time Setup)
```
User: "Install my skills from GitHub"
Claude: [runs install-skills.sh script]
Claude: [views INSTALLED_SKILLS_MANIFEST.md]
Claude: "Installed 15 skills. Skills will load automatically when needed."
```

### Automatic Loading
```
User: "Map this codebase"
Claude: [manifest indicated mapping-codebases triggers on "map"]
Claude: [views /home/claude/skills/mapping-codebases/SKILL.md]
Claude: [executes mapping]
```

### Explicit Loading
```
User: "Load the updating-knowledge skill"
Claude: [views /home/claude/skills/updating-knowledge/SKILL.md]
Claude: "Loaded updating-knowledge skill. Ready for research."
```

### List Available
```
User: "What skills are installed?"
Claude: [references manifest from memory]
Claude: "Available: categorizing-bsky-accounts, charting-vega-lite..."
```

## How It Works

### Installation Flow
1. Clones/updates `github.com/oaustegard/claude-skills`
2. Copies all skill directories to `/home/claude/skills/`
3. Removes VERSION files (workflow metadata)
4. Parses each SKILL.md for frontmatter:
   - First `# Heading` → skill name
   - Line after `**Purpose:**` → description
   - Fallback to first paragraph
5. Generates `INSTALLED_SKILLS_MANIFEST.md` with XML structure
6. Claude views manifest only (not individual skills)

### Just-In-Time Loading
- Claude recognizes trigger patterns from manifest descriptions
- When triggered, uses `view` on specific skill's SKILL.md
- Applies loaded instructions for that task
- Subsequent triggers can load different skills

### Manifest Structure
```xml
<available_skills>
<skill>
<n>mapping-codebases</n>
<description>Generate navigable code maps for unfamiliar codebases</description>
<location>/home/claude/skills/mapping-codebases/SKILL.md</location>
</skill>
...
</available_skills>
```

## Files Included

- **SKILL.md** - Main skill instructions for Claude
- **VERSION** - Version tracking (1.0.0)
- **README.md** - This file
- **install-skills.sh** - Installation script executed by Claude

## Limitations

- **Single-conversation scope:** Installed skills don't persist to new chats
- **Manual re-installation:** Each conversation needs fresh installation
- **Not in native inventory:** Won't appear in Claude's initial `<available_skills>` list until installed

## Installation to Claude.ai

1. Download ZIP from releases or create one from this directory
2. Upload to Claude.ai Skills Settings
3. Use in conversation: "Install my skills from GitHub"

## Repository

Part of: [github.com/oaustegard/claude-skills](https://github.com/oaustegard/claude-skills)

## License

MIT
