#!/bin/bash
# Install all skills from github.com/oaustegard/claude-skills
# This script is executed by Claude when the installing-skills skill is triggered

set -e

REPO_DIR="/home/claude/claude-skills"
SKILLS_DIR="/home/claude/skills"
MANIFEST="${SKILLS_DIR}/INSTALLED_SKILLS_MANIFEST.md"

echo "==> Installing skills from github.com/oaustegard/claude-skills"

# Clone or update repository
if [ ! -d "$REPO_DIR" ]; then
    echo "==> Cloning repository..."
    git clone https://github.com/oaustegard/claude-skills.git "$REPO_DIR"
else
    echo "==> Updating repository..."
    cd "$REPO_DIR" && git pull origin main
fi

# Setup skills directory
mkdir -p "$SKILLS_DIR"
cd "$REPO_DIR"

# Initialize manifest
cat > "$MANIFEST" << 'EOF'
# Installed Skills Manifest

Skills available for loading in this conversation. To activate a skill, Claude should use the `view` tool on its SKILL.md file.

<available_skills>
EOF

# Process each skill directory
count=0
for skill_dir in */; do
    skill_name=$(basename "$skill_dir")
    skill_file="${skill_dir}SKILL.md"
    
    # Skip non-skill directories
    [[ "$skill_name" =~ ^(templates|\.github|uploads)$ ]] && continue
    [ ! -f "$skill_file" ] && continue
    
    echo "==> Processing: $skill_name"
    
    # Install skill to working directory
    mkdir -p "${SKILLS_DIR}/${skill_name}"
    cp -r "${skill_dir}"* "${SKILLS_DIR}/${skill_name}/"
    rm -f "${SKILLS_DIR}/${skill_name}/VERSION"
    
    # Extract metadata from frontmatter
    name_line=$(head -20 "$skill_file" | grep -m1 "^# " | sed 's/^# //' || echo "$skill_name")
    description=$(awk '
        /\*\*Purpose:\*\*|^\*\*Description:\*\*/ { 
            getline; 
            gsub(/^[ \t]+/, ""); 
            gsub(/\*\*/, ""); 
            print; 
            exit 
        }
    ' "$skill_file")
    
    # Fallback to first paragraph if no Purpose/Description found
    [ -z "$description" ] && description=$(awk '/^[A-Z]/ && !/^#/ && !seen { print; seen=1; exit }' "$skill_file")
    [ -z "$description" ] && description="Skill for ${skill_name}"
    
    # Add skill to manifest
    cat >> "$MANIFEST" << SKILL_EOF
<skill>
<n>
${skill_name}
</n>
<description>
${description}
</description>
<location>
/home/claude/skills/${skill_name}/SKILL.md
</location>
</skill>

SKILL_EOF
    
    ((count++))
done

# Close manifest
echo "</available_skills>" >> "$MANIFEST"

echo ""
echo "✓ Installed $count skills"
echo "  Manifest: $MANIFEST"
echo ""
echo "Next: Claude should 'view $MANIFEST' to see available skills"
