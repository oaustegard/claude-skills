# mapping-codebases v2 - Changelog

## Overview
Updated skill with improvements for better scalability and usability based on testing with real-world codebases (click, Flask, Django).

## Changes Made

### 1. Installation: pip → uv
**Before:**
```bash
pip install tree-sitter==0.21.3 tree-sitter-languages==1.10.2 --break-system-packages -q
```

**After:**
```bash
uv pip install tree-sitter==0.21.3 tree-sitter-languages==1.10.2
```

**Benefit:** Much faster installation, simpler syntax.

---

### 2. Directory Statistics
**Added:** Summary stats in map headers

**Example:**
```markdown
# utils/
*Files: 40 | Subdirectories: 1*
```

**Benefit:** Quickly assess directory scope without counting manually.

---

### 3. Export/Import Counts
**Added:** Show total count when lists are truncated

**Before:**
```markdown
- **cache.py** — exports: `patch_cache_control, get_max_age`... — imports: `time, collections`...
```

**After:**
```markdown
- **cache.py** — exports (10): `patch_cache_control, get_max_age`... — imports (11): `time, collections`...
```

**Benefit:** Know the full API surface without expanding truncated lists. "exports (17)" signals complex module, "exports: 2" signals simple utility.

---

### 4. Skip Patterns
**Added:** `--skip` flag to exclude directory patterns

**Usage:**
```bash
python codemap.py /path --skip locale,migrations,tests
```

**Real-world impact:**
- Django without skip: **1,298 maps**
- Django with `--skip locale,migrations`: **138 maps** (90% reduction)

**Benefit:** Exclude noise directories (100+ locale subdirs, test snapshots, auto-generated migrations) to focus on actual source code.

---

## Testing Results

### Django (883 Python files across 2,454 directories)

**Without skip patterns:**
- Generated: 1,298 maps
- Largest map: 114 lines (locale directory with 100+ language subdirs)
- Average map: ~8 lines

**With `--skip locale,migrations`:**
- Generated: 138 maps (90% fewer)
- Maps stay focused on source code
- Navigation remains fast and relevant

### Hierarchical Structure Validation

**Key insight:** You never load all maps at once. Each map only shows:
- Its immediate subdirectories (with links)
- Its immediate files

**Navigation flow:**
1. Read root map → see 15 top-level areas
2. Pick area (e.g., `db/`) → read that map
3. Drill down as needed

Even massive codebases stay manageable because each map is small (~25 lines typical).

---

## Skill Structure

```
mapping-codebases-v2/
├── SKILL.md                 # Updated instructions
└── scripts/
    └── codemap.py          # Enhanced script with all improvements
```

---

## Follows crafting-instructions Principles

✅ **Imperative construction** - "Generate maps", "Use when", "Skip patterns"
✅ **Strategic over procedural** - Explains workflow integration, not step-by-step
✅ **Context provided** - Explains WHY features exist (scalability, noise reduction)
✅ **Trust base behavior** - Assumes Claude knows basics, focuses on skill-specific needs
✅ **Positive directives** - States what to do, not what to avoid

---

## Migration Notes

**If you have existing maps:**
1. Clean old maps: `python codemap.py /path --clean`
2. Regenerate with v2: `python codemap.py /path --skip locale,migrations`

**Backwards compatible:** v2 script works exactly like v1 without flags. Skip patterns are optional.
