# getting-env

Universal environment variable loader for AI agent environments.

Works across:
- **Claude.ai Projects** — reads from `/mnt/project/` knowledge files
- **Claude Code** (desktop & web) — reads from `~/.claude/settings.json`
- **OpenAI Codex** — reads from `~/.codex/config.toml`
- **Jules (Google)** — reads from environment settings
- **Standard environments** — reads from `.env` files and `os.environ`

## Installation

Copy `scripts/getting_env.py` to your project or skill directory.

No external dependencies required (standard library only).

## Usage

```python
from getting_env import get_env, detect_environment

# Get a variable (auto-searches all sources)
token = get_env("TURSO_TOKEN", required=True)

# With default value
port = get_env("PORT", default="8080")

# See what environment we're in
env = detect_environment()  # "claude.ai", "claude-code-desktop", "codex", etc.
```

## Documentation

See [SKILL.md](SKILL.md) for full API reference and credential file formats.

## Replaces

This skill supersedes the older `api-credentials` skill with:
- Multi-platform support (not just local development)
- Auto-detection of environment
- Better error messages per platform
- Caching for performance
- No external dependencies

## License

MIT
